"""
Task Automation with Python Scripts
-----------------------------------
Three small automation tasks in one file, chosen from a simple menu:

  A) Move all .jpg files from one folder to a new folder   (os, shutil)
  B) Extract unique email addresses from a .txt file       (re, file handling)
  C) Scrape the <title> of a fixed webpage and save it     (requests, re)

Install the only third-party library needed (for option C):
    pip install requests
"""

import html
import os
import re
import shutil

try:
    import requests
except ImportError:  # lets options A and B still work without requests
    requests = None


# ----------------------------------------------------------------------
# Idea A: Move all .jpg files from one folder to another
# ----------------------------------------------------------------------
def move_jpg_files(source_folder, destination_folder):
    """Move every .jpg file from source_folder into destination_folder."""
    # Handle: source folder does not exist
    if not os.path.isdir(source_folder):
        print(f"Error: source folder '{source_folder}' does not exist.")
        return

    if os.path.abspath(source_folder) == os.path.abspath(destination_folder):
        print("Error: source and destination folders must be different.")
        return

    # Find .jpg files (case-insensitive, so photo.JPG is included too)
    jpg_files = [
        name for name in os.listdir(source_folder)
        if name.lower().endswith(".jpg")
        and os.path.isfile(os.path.join(source_folder, name))
    ]

    # Handle: no .jpg files found
    if not jpg_files:
        print(f"No .jpg files found in '{source_folder}'. Nothing to move.")
        return

    # Create the destination folder if it does not exist
    os.makedirs(destination_folder, exist_ok=True)

    moved = []
    for name in jpg_files:
        src_path = os.path.join(source_folder, name)
        dst_path = os.path.join(destination_folder, name)

        # Do not overwrite a file that already exists in the destination
        if os.path.exists(dst_path):
            print(f"Skipped '{name}' (a file with that name already exists in destination).")
            continue

        try:
            shutil.move(src_path, dst_path)
            moved.append(name)
        except OSError as error:
            print(f"Could not move '{name}': {error}")

    print(f"\nMoved {len(moved)} file(s) to '{destination_folder}':")
    for name in moved:
        print(f"  - {name}")


# ----------------------------------------------------------------------
# Idea B: Extract email addresses from a text file
# ----------------------------------------------------------------------
EMAIL_PATTERN = r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"


def extract_emails(input_file, output_file):
    """Find all emails in input_file, remove duplicates, save to output_file."""
    # Handle: missing input file
    try:
        with open(input_file, "r", encoding="utf-8", errors="ignore") as file:
            text = file.read()
    except FileNotFoundError:
        print(f"Error: input file '{input_file}' was not found.")
        return
    except OSError as error:
        print(f"Error: could not read '{input_file}': {error}")
        return

    found = re.findall(EMAIL_PATTERN, text)

    # Remove duplicates (case-insensitive) but keep the original order
    unique_emails = []
    seen = set()
    for email in found:
        key = email.lower()
        if key not in seen:
            seen.add(key)
            unique_emails.append(email)

    if not unique_emails:
        print(f"No email addresses found in '{input_file}'.")
        return

    try:
        with open(output_file, "w", encoding="utf-8") as file:
            for email in unique_emails:
                file.write(email + "\n")
    except OSError as error:
        print(f"Error: could not write to '{output_file}': {error}")
        return

    print(f"Found {len(found)} email(s), {len(unique_emails)} unique.")
    print(f"Saved to '{output_file}':")
    for email in unique_emails:
        print(f"  - {email}")


# ----------------------------------------------------------------------
# Idea C: Scrape the title of a fixed webpage
# ----------------------------------------------------------------------
def scrape_page_title(url="https://example.com", output_file="page_title.txt"):
    """Download a page, pull out its <title> with re, and save it to a file."""
    if requests is None:
        print("The 'requests' library is not installed.")
        print("Install it with:  pip install requests")
        return

    print(f"Fetching {url} ...")
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()  # raises an error for 404, 500, etc.
    except requests.exceptions.Timeout:
        print("Error: the request timed out. Try again later.")
        return
    except requests.exceptions.ConnectionError:
        print("Error: could not connect. Check your internet connection.")
        return
    except requests.exceptions.HTTPError as error:
        print(f"Error: the server returned an error: {error}")
        return
    except requests.exceptions.RequestException as error:
        print(f"Error: something went wrong with the request: {error}")
        return

    # Extract <title>...</title> using a regular expression
    match = re.search(r"<title[^>]*>(.*?)</title>", response.text,
                      re.IGNORECASE | re.DOTALL)
    if not match:
        print("No <title> tag was found on that page.")
        return

    title = html.unescape(match.group(1)).strip()

    try:
        with open(output_file, "w", encoding="utf-8") as file:
            file.write(title + "\n")
    except OSError as error:
        print(f"Error: could not write to '{output_file}': {error}")
        return

    print(f"Page title: {title}")
    print(f"Saved to '{output_file}'.")


# ----------------------------------------------------------------------
# Simple menu
# ----------------------------------------------------------------------
def ask(prompt, default):
    """Ask the user for a value; press Enter to use the default."""
    value = input(f"{prompt} [{default}]: ").strip()
    return value if value else default


def main():
    while True:
        print("\n===== Task Automation Menu =====")
        print("1. Move .jpg files to a new folder")
        print("2. Extract emails from a text file")
        print("3. Scrape the title of https://example.com")
        print("0. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            source = ask("Source folder", "photos")
            destination = ask("Destination folder", "jpg_images")
            move_jpg_files(source, destination)
        elif choice == "2":
            input_file = ask("Input file", "input.txt")
            output_file = ask("Output file", "emails.txt")
            extract_emails(input_file, output_file)
        elif choice == "3":
            scrape_page_title("https://example.com", "page_title.txt")
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 0, 1, 2 or 3.")


if __name__ == "__main__":
    main()
